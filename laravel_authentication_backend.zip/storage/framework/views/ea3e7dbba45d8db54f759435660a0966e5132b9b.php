<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel Auth</title>
    </head>
    <body>
        <div>
            <h2>Autenticaci&oacute;n 5</h2>
            <?php if(Auth::user()): ?>
            <p> Hello <?php echo e(Auth::user()->name); ?></p>
            <h3><a href="<?php echo e(route('logout')); ?>">Logout</a></h3>
            <?php else: ?>
            <h3><a href="<?php echo e(route('login')); ?>">Login</a></h3>
            <?php endif; ?>
        </div>
    </body>
</html>
<?php /**PATH D:\src\web\jlc-back\resources\views/authHome.blade.php ENDPATH**/ ?>